

package managesystem.storagemanagementsystem;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.*;
import java.util.Comparator;



public class Editar extends javax.swing.JInternalFrame {
ArrayList<dadosRelatorio> relatorio = new ArrayList<>();

    public class dadosRelatorio{
        private String nomeProduto;
        private String quantidadeProduto;
        private String precoUnitarioProduto;
        private String idProduto;
       

        public dadosRelatorio(String nomeProduto, String precoUnitarioProduto,String quantidadeProduto, String idProduto){
            
            
            this.nomeProduto = nomeProduto;
            this.precoUnitarioProduto = precoUnitarioProduto;
            this.quantidadeProduto = quantidadeProduto;
            this.idProduto = idProduto;
            
            
            
        }
        
        public String getNomeProduto() {
            return nomeProduto;
        }

     
        public void setNomeProduto(String nomeProduto) {
            this.nomeProduto = nomeProduto;
        }

     
        public String getQuantidadeProduto() {
            return quantidadeProduto;
        }

       
        public void setQuantidadeProduto(String quantidadeProduto) {
            this.quantidadeProduto = quantidadeProduto;
        }

      
        public String getPrecoUnitarioProduto() {
            return precoUnitarioProduto;
        }

      
        public void setPrecoUnitarioProduto(String precoUnitarioProduto) {
            this.precoUnitarioProduto = precoUnitarioProduto;
        }

   
        public String getIdProduto() {
            return idProduto;
        }

        
        public void setIdProduto(String idProduto) {
            this.idProduto = idProduto;
        }
        
       
      
    

        @Override
        public String toString() {
            return "Nome do produto: " + nomeProduto + ", Quantidade do produto: " + quantidadeProduto + ", Preço unitário produto: R$ " + precoUnitarioProduto + ", Id do produto: " + idProduto + "\n";
        }
        
       
        
    }
    public Editar() {
        initComponents();
        DefaultTableModel modelo = (DefaultTableModel) jTProdutos.getModel();
        jTProdutos.setRowSorter(new TableRowSorter(modelo));
     
    
    
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        textNome = new javax.swing.JTextField();
        textPreco = new javax.swing.JTextField();
        textQtd = new javax.swing.JTextField();
        buttonAdicionar = new javax.swing.JButton();
        buttonExcluir = new javax.swing.JButton();
        buttonAtualizar = new javax.swing.JButton();
        buttonSalvar = new javax.swing.JButton();
        jValorTotal = new javax.swing.JLabel();
        jValorMedio = new javax.swing.JLabel();
        textValorTotal = new javax.swing.JLabel();
        textValorMedio = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTProdutos = new javax.swing.JTable();

        setClosable(true);

        jLabel1.setText("Nome");

        jLabel2.setText("Quantidade");

        jLabel3.setText("Preço em R$");

        textPreco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textPrecoActionPerformed(evt);
            }
        });

        buttonAdicionar.setText("Adicionar");
        buttonAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAdicionarActionPerformed(evt);
            }
        });

        buttonExcluir.setText("Excluir");
        buttonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonExcluirActionPerformed(evt);
            }
        });

        buttonAtualizar.setText("Atualizar");
        buttonAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAtualizarActionPerformed(evt);
            }
        });

        buttonSalvar.setText("Salvar");
        buttonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonSalvarActionPerformed(evt);
            }
        });

        jValorTotal.setText("Valor Total");

        jValorMedio.setText("Valor Médio em R$");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jValorTotal)
                    .addComponent(jValorMedio))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(textNome, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                                .addComponent(textPreco)
                                .addComponent(textQtd))
                            .addComponent(textValorTotal))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(buttonAdicionar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(buttonExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(buttonAtualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(buttonSalvar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(103, 103, 103))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(textValorMedio)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(textNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(buttonAdicionar)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(textPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(buttonExcluir)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(buttonAtualizar)
                        .addGap(28, 28, 28)
                        .addComponent(buttonSalvar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(textQtd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jValorTotal)
                            .addComponent(textValorTotal))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jValorMedio)
                            .addComponent(textValorMedio))))
                .addGap(19, 19, 19))
        );

        jTProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Preço", "Qtd", "Id"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTProdutos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTProdutosMouseClicked(evt);
            }
        });
        jTProdutos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTProdutosKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTProdutos);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 935, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 379, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textPrecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textPrecoActionPerformed
     
    }//GEN-LAST:event_textPrecoActionPerformed

    private void buttonAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAdicionarActionPerformed
       double preco;
       double quantidade; 
     String nomeProduto = textNome.getText();
     String precoUnitarioProduto = textPreco.getText();
     String quantidadeProduto = textQtd.getText();
     String idProduto;
     
     
     Random random = new Random();
     
       DefaultTableModel dtmProdutos = (DefaultTableModel) jTProdutos.getModel();
    
     
       try{
      
          preco = Double.parseDouble(textPreco.getText());
          quantidade = Integer.parseInt(textQtd.getText());
          
          
          idProduto = String.valueOf(random.nextInt(10000, 99999));
          
          for(int i = 0; i < relatorio.size() ; i++){
          if(idProduto.equals(relatorio.get(i).getIdProduto())){
              int idProduct = Integer.parseInt(relatorio.get(i).getIdProduto());
              idProduct++;
              
              idProduto = String.valueOf(idProduct);
              
          }           
              
          }

          
           Object[] dados = {nomeProduto, precoUnitarioProduto,quantidadeProduto, idProduto};    
       dtmProdutos.addRow(dados);
       relatorio.add(new dadosRelatorio(nomeProduto, precoUnitarioProduto, quantidadeProduto, idProduto));
      
     
       
       
       }catch(Exception e){
           
             JOptionPane.showMessageDialog(null, "Digite os valores corretos para cada campo!");
           
       }
        
     
        
      
    }//GEN-LAST:event_buttonAdicionarActionPerformed

    private void buttonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonExcluirActionPerformed
        try{
        DefaultTableModel dtmProdutos = (DefaultTableModel) jTProdutos.getModel();
        
        
        for(int i = 0; i < relatorio.size(); i++){
           
           if(relatorio.get(i).getIdProduto().equals(String.valueOf(jTProdutos.getValueAt(jTProdutos.getSelectedRow(), 3)))){
               
             
              relatorio.remove(i);
               
                
            }
               
        }
            dtmProdutos.removeRow(jTProdutos.getSelectedRow());
        }catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Selecione o item antes de excluir!");
            
        }
        
    
        
       
    }//GEN-LAST:event_buttonExcluirActionPerformed

    private void jTProdutosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTProdutosKeyReleased
       
    }//GEN-LAST:event_jTProdutosKeyReleased

    private void jTProdutosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTProdutosMouseClicked
        if (jTProdutos.getSelectedRow() != -1){
           textNome.setText(jTProdutos.getValueAt(jTProdutos.getSelectedRow(), 0).toString());
           textPreco.setText(jTProdutos.getValueAt(jTProdutos.getSelectedRow(), 1).toString());
           textQtd.setText(jTProdutos.getValueAt(jTProdutos.getSelectedRow(), 2).toString());
        
       }
    }//GEN-LAST:event_jTProdutosMouseClicked

    private void buttonAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAtualizarActionPerformed
       try{
          jTProdutos.setValueAt(textNome.getText(), jTProdutos.getSelectedRow(),0);
          jTProdutos.setValueAt(textPreco.getText(), jTProdutos.getSelectedRow(),1);
          jTProdutos.setValueAt(textQtd.getText(), jTProdutos.getSelectedRow(),2);
           
           for(int i = 0; i < relatorio.size(); i++){
           
            if(relatorio.get(i).getIdProduto().equals(String.valueOf(jTProdutos.getValueAt(jTProdutos.getSelectedRow(), 3)))){
                
                relatorio.get(i).setNomeProduto(textNome.getText());
                relatorio.get(i).setQuantidadeProduto(textQtd.getText());
                relatorio.get(i).setPrecoUnitarioProduto(textPreco.getText());
                
                
            }
               
               
        }
           
       }catch(Exception e){
           
            JOptionPane.showMessageDialog(null, "Selecione o item antes de atualizar!");
       }
       
       
    }//GEN-LAST:event_buttonAtualizarActionPerformed

    public String valores(double valorEstoque, double valorMedio){
        
        String stockValue = String.valueOf(valorEstoque);
        String averageValue = String.valueOf(valorMedio);
        
        return "Valor total do estoque: R$ " + stockValue + ", valor médio do estoque: R$ " + averageValue + "\n\n";
    }
    
    private void buttonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonSalvarActionPerformed
   double valorTotalEstoque = 0;
   double valorMedioEstoque;
   double somadorQuantidade = 0; 
        
        for(int i = 0; i < relatorio.size(); i++){
          
           valorTotalEstoque += Double.parseDouble(relatorio.get(i).getPrecoUnitarioProduto() ) * Double.parseDouble( relatorio.get(i).getQuantidadeProduto());
          somadorQuantidade += Double.parseDouble( relatorio.get(i).getQuantidadeProduto());   
          
      }
        valorMedioEstoque = valorTotalEstoque / somadorQuantidade;
        
       
        textValorTotal.setText(String.valueOf(valorTotalEstoque));
        textValorMedio.setText(String.valueOf(valorMedioEstoque));
      JOptionPane.showMessageDialog(null, "Relatório salvo na pasta do arquivo!");
        try( FileWriter arquivo = new FileWriter("RelatorioEstoque.txt");
                
              PrintWriter gravarArquivo = new PrintWriter(arquivo);) {
            
            gravarArquivo.append(valores(valorTotalEstoque, valorMedioEstoque));
         
            for(int i = 0; i < relatorio.size(); i++){
                
            gravarArquivo.append(relatorio.get(i).toString());
                
            }
             
            
            
        } catch (Exception e) {
          
            
             JOptionPane.showMessageDialog(null, "Impossível gerar relatório corretamente!");
            
        }
        
        
    }//GEN-LAST:event_buttonSalvarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonAdicionar;
    private javax.swing.JButton buttonAtualizar;
    private javax.swing.JButton buttonExcluir;
    private javax.swing.JButton buttonSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTProdutos;
    private javax.swing.JLabel jValorMedio;
    private javax.swing.JLabel jValorTotal;
    private javax.swing.JTextField textNome;
    private javax.swing.JTextField textPreco;
    private javax.swing.JTextField textQtd;
    private javax.swing.JLabel textValorMedio;
    private javax.swing.JLabel textValorTotal;
    // End of variables declaration//GEN-END:variables
}
