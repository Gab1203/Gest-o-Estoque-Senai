/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package managesystem.storagemanagementsystem;

import static java.awt.GridBagConstraints.BOTH;
import javax.swing.JFrame;

public class Menu extends javax.swing.JFrame {

    
    public Menu() {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu5 = new javax.swing.JMenu();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuSobre = new javax.swing.JMenu();
        jMenuSaibaMais = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenuEstoque = new javax.swing.JMenu();
        jMenuEditarEstoque = new javax.swing.JMenuItem();

        jMenu5.setText("jMenu5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 277, Short.MAX_VALUE)
        );

        jMenuSobre.setText("Sobre");
        jMenuSobre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuSobreActionPerformed(evt);
            }
        });

        jMenuSaibaMais.setText("Saiba mais informações");
        jMenuSaibaMais.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuSaibaMaisActionPerformed(evt);
            }
        });
        jMenuSobre.add(jMenuSaibaMais);

        jMenuBar1.add(jMenuSobre);
        jMenuBar1.add(jMenu2);

        jMenuEstoque.setText("Estoque ");
        jMenuEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuEstoqueActionPerformed(evt);
            }
        });

        jMenuEditarEstoque.setText("Editar estoque");
        jMenuEditarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuEditarEstoqueActionPerformed(evt);
            }
        });
        jMenuEstoque.add(jMenuEditarEstoque);

        jMenuBar1.add(jMenuEstoque);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1)
        );

        jDesktopPane1.getAccessibleContext().setAccessibleName("Sistema de Gerenciamento de Estoque");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuEstoqueActionPerformed
     
    }//GEN-LAST:event_jMenuEstoqueActionPerformed

    private void jMenuEditarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuEditarEstoqueActionPerformed
        Editar editar = new Editar();
      jDesktopPane1.add(editar);
      editar.setVisible(true);
    }//GEN-LAST:event_jMenuEditarEstoqueActionPerformed

    private void jMenuSobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuSobreActionPerformed
    
    }//GEN-LAST:event_jMenuSobreActionPerformed

    private void jMenuSaibaMaisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuSaibaMaisActionPerformed
     Sobre about = new Sobre();
        jDesktopPane1.add(about);
        about.setVisible(true);
    }//GEN-LAST:event_jMenuSaibaMaisActionPerformed

   
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuEditarEstoque;
    private javax.swing.JMenu jMenuEstoque;
    private javax.swing.JMenu jMenuSaibaMais;
    private javax.swing.JMenu jMenuSobre;
    // End of variables declaration//GEN-END:variables
}
